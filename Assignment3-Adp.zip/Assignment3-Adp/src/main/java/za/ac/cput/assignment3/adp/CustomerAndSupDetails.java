/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.assignment3.adp;

/**
 *
 * @author Edrico fielies 219447500
 */
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class CustomerAndSupDetails {

	static ArrayList<Customer> listOfCustomers = new ArrayList<Customer>();
	static ArrayList<Supplier> listOfSuppliers = new ArrayList<Supplier>();

	public static void loadData() {
		//Arraylist instantiated to save read file information

		int age;

		//Reading file data and storing it in appropriate arraylist
		try
		{
			FileInputStream is = new FileInputStream("stakeholder.ser");
			ObjectInputStream os = new ObjectInputStream(is);

			listOfCustomers.add((Customer) os.readObject());
			listOfSuppliers.add((Supplier) os.readObject());
			listOfCustomers.add((Customer) os.readObject());
			listOfSuppliers.add((Supplier) os.readObject());
			listOfSuppliers.add((Supplier) os.readObject());
			listOfCustomers.add((Customer) os.readObject());
			listOfCustomers.add((Customer) os.readObject());
			listOfSuppliers.add((Supplier) os.readObject());
			listOfSuppliers.add((Supplier) os.readObject());				
			listOfCustomers.add((Customer) os.readObject());
			listOfCustomers.add((Customer) os.readObject());

			is.close();
			os.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
			return;
		}catch(ClassNotFoundException e){
			e.printStackTrace();
			return;
		}
	}
	
	//Returns the age value for the customer
	public static int customerAge(int i) throws ParseException {
		int age;
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM YYYY");	
		Date d = new Date();
		int currentYear = d.getYear();
		int customerBirthYear = dateFormat.parse(listOfCustomers.get(i).getDateOfBirth()).getYear();
		
		age = currentYear - customerBirthYear;
		
		return age;
	}
	
	//Formats date to one needed for the assignment
	public static String changeDateFormat(int i) throws ParseException {
		
		String targetFormat = "dd MMM YYYY";
        String currentFormat = "yyyy-MM-dd";
        String sourceDate = listOfCustomers.get(i).getDateOfBirth();
        DateFormat srcDf = new SimpleDateFormat(currentFormat);
        DateFormat destDf = new SimpleDateFormat(targetFormat);
        String targetDate = null;
        try {
            Date date = srcDf.parse(sourceDate);
            targetDate = destDf.format(date);
        } catch (ParseException ex) {
            ex.printStackTrace();
        }	                                          
        return targetDate;
	}
	
	static int rentsNumber = 0;
	static int dontRent = 0;
	//Creates the output text file for the customer Arraylist
	public static void saveDataCustomer() throws ParseException{
		try {
			FileOutputStream fo = new FileOutputStream("customerOutFile.txt");
			BufferedWriter os = new BufferedWriter( new OutputStreamWriter( fo, Charset.forName("UTF-8") ) );
			os.write("========================== CUSTOMERS ============================" + "\n");
			os.write("	ID			Name		Surname		Date of birth		Age  " + "\n");
			os.write("=================================================================" + "\n");
			for(int i = 0; i < 6; i++) {
				boolean customerRent = listOfCustomers.get(i).getCanRent();
				if(customerRent != true) {
					dontRent++;
				}else {
					rentsNumber++;
				}
				listOfCustomers.get(i).setDateOfBirth(changeDateFormat(i).toString());
				os.write(String.format("%-12s\t%-10s\t%-8s\t%-15s\t%6d", listOfCustomers.get(i).getStHolderId(), listOfCustomers.get(i).getFirstName(), listOfCustomers.get(i).getSurName(), listOfCustomers.get(i).getDateOfBirth(), customerAge(i)) + "\n");
			}
			os.write('\n' + "Number of customers who can rent: " + rentsNumber + '\n');
			os.write("Number of customers who cannot rent: " + dontRent);
			os.close();
			fo.close();
			System.out.println("Data saved in customerOutFile.txt");
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	
	//Creates the output text file for the supplier Arraylist
	public static void saveDataSupplier(){
		try {
			FileOutputStream fo = new FileOutputStream("supplierOutFile.txt");
			BufferedWriter os = new BufferedWriter( new OutputStreamWriter( fo, Charset.forName("UTF-8") ) );
			os.write("========================== CUSTOMERS ============================" + "\n");
			os.write("ID		Name					Prod Type		Description    " + "\n");
			os.write("=================================================================" + "\n");
			for(int i = 0; i < 5; i++) {
				os.write(String.format("%-5s\t%-20s\t%-15s\t%-10s", listOfSuppliers.get(i).getStHolderId(), listOfSuppliers.get(i).getName(), listOfSuppliers.get(i).getProductType(), listOfSuppliers.get(i).getProductDescription()) + "\n");
			}
			os.close();
			fo.close();
			System.out.println("Data saved in supplierOutFile.txt");
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	public static void sortData() {
		//Sorts Arraylists
		Collections.sort(listOfCustomers, new Comparator<Customer>() {
			@Override
			public int compare(Customer o1, Customer o2) {
				return o1.getStHolderId().compareTo(o2.getStHolderId());
			}
		});

		Collections.sort(listOfSuppliers, new Comparator<Supplier>() {
			@Override
			public int compare(Supplier o1, Supplier o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});
	}
	

	public static void main(String[] args) throws ParseException
	{
		loadData();
		sortData();
		saveDataCustomer();
		saveDataSupplier();
	}
}
